﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arduino
{
    public partial class frmLogs : Form
    {
        public frmLogs()
        {
            InitializeComponent();
        }

        private void frmLogs_Load(object sender, EventArgs e)
        {
            Users usersCtrl = new Users();
            usersCtrl.getLogs(gridLogs);
        }

        private void gridLogs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
